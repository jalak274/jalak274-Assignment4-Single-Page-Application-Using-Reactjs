import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer className='bg-secondary text-center'>
        <div className="footer-container p-4">&#169;2022 Nayan Yadav, Inc. All rights reserved.</div>
      </footer>
    );
  }
}
export default Footer;
