import React, { Component } from 'react';

class Header extends Component {
  render() {
    return (
      <header className='bg-primary'>
        <h2 className="header-container p-4 logo">Blog Post</h2>
      </header>
    );
  }
}
export default Header;
